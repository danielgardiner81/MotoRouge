﻿using UnityEngine;

namespace Common.Authoring
{
    public class GroundAuthoring : MonoBehaviour
    {
        public float width = 50f;
        public float length = 50f;
    }
}
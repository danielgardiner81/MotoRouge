﻿using UnityEngine;

namespace Common.Authoring
{
    public class CameraSyncAuthoring : MonoBehaviour
    {
        public Camera unityCamera;
    }
}